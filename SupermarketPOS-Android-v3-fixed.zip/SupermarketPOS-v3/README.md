# Supermarket POS Android v3

Offline-first supermarket POS starter project.

## v3 build fixes
- Gradle 8.9 in GitHub Actions
- Java 17 source/target compatibility
- Kotlin JVM target 17
- GitHub Actions builds a debug APK artifact

## Current features
- Product barcode lookup
- Camera barcode scanner (CameraX + ML Kit)
- Cart and GST calculation
- Cash / UPI / Card payment recording
- Local SQLite database

The GitHub Actions workflow builds `app-debug.apk` as an artifact.
