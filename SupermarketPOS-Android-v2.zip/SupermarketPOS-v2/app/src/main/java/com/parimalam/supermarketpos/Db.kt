package com.parimalam.supermarketpos

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

data class Product(val barcode:String,val name:String,val price:Double,val gst:Double,var stock:Double)

class Db(context:Context): SQLiteOpenHelper(context,"pos.db",null,1){
 override fun onCreate(db:SQLiteDatabase){
  db.execSQL("CREATE TABLE products(barcode TEXT PRIMARY KEY,name TEXT,price REAL,gst REAL,stock REAL)")
  db.execSQL("CREATE TABLE sales(id INTEGER PRIMARY KEY AUTOINCREMENT,created INTEGER,total REAL,payment TEXT)")
  val samples=listOf(Product("8901234567890","Rice 5kg",320.0,5.0,25.0),Product("8901234567891","Sugar 1kg",52.0,5.0,50.0),Product("8901234567892","Milk 1L",60.0,0.0,40.0))
  samples.forEach{ p-> val v=ContentValues().apply{put("barcode",p.barcode);put("name",p.name);put("price",p.price);put("gst",p.gst);put("stock",p.stock)};db.insert("products",null,v)}
 }
 override fun onUpgrade(db:SQLiteDatabase,o:Int,n:Int){ }
 fun product(code:String):Product?{ val c=readableDatabase.rawQuery("SELECT barcode,name,price,gst,stock FROM products WHERE barcode=? OR name LIKE ? LIMIT 1",arrayOf(code,"%$code%")); c.use{if(it.moveToFirst()) return Product(it.getString(0),it.getString(1),it.getDouble(2),it.getDouble(3),it.getDouble(4))};return null }
 fun saveSale(total:Double,payment:String){val v=ContentValues().apply{put("created",System.currentTimeMillis());put("total",total);put("payment",payment)};writableDatabase.insert("sales",null,v)}
}
