package com.parimalam.supermarketpos

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.common.InputImage
import java.util.concurrent.Executors

class ScannerActivity:Activity(){
 private lateinit var preview:PreviewView; private var done=false; private val exec=Executors.newSingleThreadExecutor()
 override fun onCreate(b:Bundle?){super.onCreate(b);setContentView(R.layout.activity_scanner);preview=findViewById(R.id.preview);if(ContextCompat.checkSelfPermission(this,Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED)ActivityCompat.requestPermissions(this,arrayOf(Manifest.permission.CAMERA),5) else start()}
 override fun onRequestPermissionsResult(r:Int,p:Array<out String>,g:IntArray){super.onRequestPermissionsResult(r,p,g);if(r==5&&g.isNotEmpty()&&g[0]==PackageManager.PERMISSION_GRANTED)start() else finish()}
 private fun start(){val f=ProcessCameraProvider.getInstance(this);f.addListener({val provider=f.get();val pre=Preview.Builder().build().also{it.surfaceProvider=preview.surfaceProvider};val analysis=ImageAnalysis.Builder().setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build();analysis.setAnalyzer(exec){proxy->if(!done){val img=proxy.image;if(img!=null){BarcodeScanning.getClient().process(InputImage.fromMediaImage(img,proxy.imageInfo.rotationDegrees)).addOnSuccessListener{list->val code=list.firstOrNull()?.rawValue;if(!code.isNullOrBlank()&&!done){done=true;setResult(RESULT_OK,intent.putExtra("barcode",code));finish()}}.addOnCompleteListener{proxy.close()}}else proxy.close()}else proxy.close()};provider.unbindAll();provider.bindToLifecycle(this,CameraSelector.DEFAULT_BACK_CAMERA,pre,analysis)},ContextCompat.getMainExecutor(this))}
 override fun onDestroy(){super.onDestroy();exec.shutdown()}
}
