package com.parimalam.supermarketpos

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.*
import java.util.Locale

class MainActivity:Activity(){
 private lateinit var db:Db; private lateinit var barcode:EditText; private lateinit var cartText:TextView; private lateinit var totalText:TextView
 private val cart=mutableListOf<Pair<Product,Double>>()
 override fun onCreate(b:Bundle?){super.onCreate(b);setContentView(R.layout.activity_main);db=Db(this)
  barcode=findViewById(R.id.etBarcode);cartText=findViewById(R.id.tvCart);totalText=findViewById(R.id.tvTotal)
  findViewById<Button>(R.id.btnScan).setOnClickListener{startActivityForResult(Intent(this,ScannerActivity::class.java),77)}
  findViewById<Button>(R.id.btnAdd).setOnClickListener{addProduct()}
  findViewById<Button>(R.id.btnCash).setOnClickListener{pay("Cash")};findViewById<Button>(R.id.btnUpi).setOnClickListener{pay("UPI")};findViewById<Button>(R.id.btnCard).setOnClickListener{pay("Card")}
  findViewById<Button>(R.id.btnStock).setOnClickListener{Toast.makeText(this,"Stock management screen is next in v2.1",Toast.LENGTH_SHORT).show()}
 }
 private fun addProduct(){val q=barcode.text.toString().trim();if(q.isEmpty())return;val p=db.product(q);if(p==null){Toast.makeText(this,"Product not found",Toast.LENGTH_SHORT).show();return};val i=cart.indexOfFirst{it.first.barcode==p.barcode};if(i>=0)cart[i]=p to cart[i].second+1 else cart.add(p to 1.0);barcode.setText("");render()}
 private fun render(){val sb=StringBuilder();var total=0.0;cart.forEach{(p,q)->val base=p.price*q;val gst=base*p.gst/100;val line=base+gst;total+=line;sb.append(p.name).append(" × ").append(q).append("  ₹").append(String.format(Locale.US,"%.2f",line)).append(" (GST ").append(p.gst).append("%)\n")};cartText.text=if(sb.isEmpty())"Cart is empty" else sb.toString();totalText.text="Total: ₹"+String.format(Locale.US,"%.2f",total)}
 private fun pay(method:String){if(cart.isEmpty()){Toast.makeText(this,"Add products first",Toast.LENGTH_SHORT).show();return};val t=cart.sumOf{it.first.price*it.second*(1+it.first.gst/100)};db.saveSale(t,method);Toast.makeText(this,"Paid ₹"+String.format(Locale.US,"%.2f",t)+" by $method",Toast.LENGTH_LONG).show();cart.clear();render()}
 override fun onActivityResult(r:Int,c:Int,d:android.content.Intent?){super.onActivityResult(r,c,d);if(r==77&&c==RESULT_OK){barcode.setText(d?.getStringExtra("barcode")?:"");addProduct()}}
}
