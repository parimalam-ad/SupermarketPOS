# Supermarket POS v2
Offline-first Android supermarket billing app.

Included in v2:
- Barcode camera scanning (ML Kit + CameraX)
- Product lookup
- GST-inclusive line calculation
- Cash / UPI / Card payment recording
- Offline SQLite product + sales database
- Sample products
- Bluetooth permissions reserved for thermal printer integration

## Build on a phone
This project includes a GitHub Actions workflow. Upload the project to a GitHub repository, then open Actions > Build Android APK. The generated APK is available as a workflow artifact.
